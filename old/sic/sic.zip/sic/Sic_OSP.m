function Result=Sic_OSP(mod)
%Object Status Plot

Yc=mod.Y_test;
[Yc_r,Yc_c]=size(Yc);

beta=mod.Beta;
vmax=mod.Vmax;
vmin=mod.Vmin;
if(Yc_r~=0 ||Yc_c~=0)
%residuals,leverage&boundary
[Res,Lev,Bound]=ResLevBound(Yc,vmax,vmin,beta);


bnum=paintResLev(Res,Lev,Bound,beta);
disp(strcat('Number of boundary objects =  ',int2str(bnum)));

else

 Res=[];
 Bound=[];
 Lev=((vmax-vmin)/2)/beta;
 Leverage=Lev
  
 %plot
 figure;
 hold on;
 axis ([0 max(size(Lev))+0.5 min(Lev)-0.5 max(Lev)+0.5]);
 plot([0 max(size(Lev))+0.5],[1 1],'k');

 plot(Lev,'s','MarkerFaceColor','g','MarkerSize',5);
  
 title('SIC-Leverage','FontSize',16);
 xlabel('Samples','FontSize',16);
 ylabel('Values','FontSize',16);
 bnum=0;
 hold off;
end
Result=struct('res',{Res},'lev',{Lev},'bound',{Bound},'bnum',{bnum});