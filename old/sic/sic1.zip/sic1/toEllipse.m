function [XX,s,yy]=toEllipse(y,t,beta)
%Ellipse
%
%
[m,n]=size(y);
[m1,n1]=size(t);

yplus=y+beta*ones(m,n);
yminus=y-beta*ones(m,n);

L=t'*t;
z=0.5*(yminus+yplus);
e=0.5*(yplus-yminus);
a0=inv(L)*t'*z;
d=e'*e+z'*t*a0-z'*z;

yy=[yplus;-yminus];
XX=[t;-t];

l=diag(L);
for i=1:length(l)
r(i)=sqrt(d/l(i));    
end
s=-1*r'+a0;

Shift=-1*min(s);
if (Shift<0)
    Shift=0;
end;

yy=yy+XX*(Shift*ones(n1,1));

s=Shift;

