function  Z=Postprocess(X,mean,Sdev)
%Results postprocessing

Z=X*diag(Sdev)+ones(size(X))*diag(mean);
%Z=(X+ones(size(X))*diag(mean))*diag(Sdev);