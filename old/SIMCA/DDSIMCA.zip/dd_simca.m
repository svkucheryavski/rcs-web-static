function varargout = dd_simca(varargin)
% DD_SIMCA
% Data Driven SIMCA (DD-SIMCA)
% 
% Syntax
% calibration mode
% [model, result] = dd_simca(TrainingSet,numPC,Name,Value) 
% 
% testing mode
% result = dd_simca(Model,NewSet)
% 
% Description
% [model, result] = dd_simca(TrainingSet,numPC,Name,Value)
% calculates the DD-SIMCA model and applies it to the test set (if
% provided). Based on provided Name-Value parameters, preprocessing may be
% applied to the TrainingSet data. If the TestSet is provided and CalculateBeta
% parameter is absent or set true, type II error Beta is calculated for the alternative class TestSet or
% each class in TestSet if it is a Matlab cellarray. 
% Note, that by default the PREPROCESSING IS NOT APPLIED to the training
% and test sets. Use Centering and Normalizing parameters to control the
% data preprocessing.
% Also note, that if Alpha parameter is not set, it is calculated by
% default, so that all samples in the training set are inside the
% acceptance area.
%
% Example
%
% numPC = 2;
% Gamma = 0.001;
% Alpha = 0.01;
% [model, result] = dd_simca(TrainingSet, numPC, ...
% 'Gamma', Gamma, 'Alpha', Alpha, 'TestSet', TestSet, ...
% 'BorderType', 'chi-square', 'Centering', true);
%
%
% result = dd_simca(Model,NewSet)
% is intended for testing of new classes of samples using a previosly created DD-SIMCA model, 
% type II error Beta is calculated for the alternative class NewSet or
% each class in NewSet if it is a cellarray. 
% In case the test set is splitting into several subclasses, the result
% structure will contain the Warning field.
%
% Example
%
% numPC = 4;
% Gamma = 0.001;
% Alpha = 0.04;
% [model, result] = dd_simca(TrainingSet, numPC, ...
% 'Gamma', Gamma, 'Alpha', Alpha, 'TestSet', internal_data_set, ...
% 'BorderType', 'chi-square', 'Centering', true);
% 
% result2 = dd_simca(model, external_test_data);
%
%
% Input Arguments
% TrainingSet - matrix (n,p), data matrix n-objects, p-variables, the Training set
% (matrix)
% 
% numPC - number of Principal components in the PCA decomposition
% (scalar)
% Must be greater than 0.
% 
% Model - structure containing the calculated parameters of the DD-SIMCA model based on the training data set
% (struct)
% 
% NewSet - matrix (m,p), data matrix m-objects, p-variables or cellarray of matrices, New or Test set
% (matrix|cellarray of matrices)
% 
% Beta - predefined type II error (optional)
% (scalar)
% Must be in the range [0,1].
% 
% Name-Value Pair Arguments
% Specify optional comma-separated pairs of Name,Value arguments. Name is the argument name and Value is the corresponding value. Name must appear inside single quotes (' '). You can specify several name and value pair arguments in any order as Name1,Value1,...,NameN,ValueN.
% Example: 'Alpha','0.01','Centering', true
% 
% Method - type of calculation of SIMCA parameters
% (string)
% 'classic' (default)| 'robust'
% 'classic' - method of moments
% 'robust' - robust methods
% 
% Gamma - outlier level
% (scalar)
% Must be in the range [0,1].
% 
% Alpha - significance level (type I error)
% (scalar)
% Must be in the range [0,1].
% 
% CalculateBeta - error calculation mode
% (logical)
% true (default) | false
% "true" - calculate beta (or alpha, if Beta parameter is set) for the test set, "false" -
% do not calculate beta.
% 
% BorderType - the border type in SIMCA plot
% (string)
% 'chi-square' (default) | 'convention'
% 'convention' - classical rectangular border
% 'chi-square' - triangular border defined for joint chi-squared distribution
% 
% Centering - data preprocessing mode
% (logical)
% false (default) | true
% "true" - mean-centering, "false" - no mean-centering 
% 
% Normalizing - data preprocessing mode
% (logical)
% false (default) | true
% "true" - normalising, "false" - no normalising 
% 
% TestSet - matrix (m,p), data matrix m-objects, p-variables or cellarray of matrices, New or Test set
% (matrix|cellarray)
% 
% Output Arguments
% model - structure containing the calculated parameters of the DD-SIMCA model based on the training data set as well as several input variables.
% (struct)
% 
% model.TrainingSet - training set
% model.numPC - number of principal components
% model.Loadings - loadings matrix
% model.EigenMatrix - matrix of eigenvalues from the SVD decomposition
% model.SD_mean - mean of normalized squared Mahalanobis distances (SD) for objects
% from the Training Set
% model.OD_mean - mean of normalized squared Euclidian distances (OD) for objects
% from the Training Set
% model.DoF_SD - number of Degrees of Freedom of chi-square distribution of SD
% model.DoF_OD - number of Degrees of Freedom of chi-square distribution of OD
% 
% model.level.critical - offset values for extreme border
% model.level.outlier - offset values for outlier border
% model.level.borderType - the border type in SIMCA plot (Equal to Input parameter "BorderType")
% 
% model.Alpha - significance level (type I error)
% model.Gamma - outlier level
% 
% model.TrainingSet_mean - mean values of the Training Set (used for preprocessing of Test Set or New Set)
% model.TrainingSet_std - standard deviation of the Training Set (used for preprocessing of Test Set or New Set)
% 
% model.EstimationMethod - type of calculation of SIMCA parameters (informational, equal to Method input parameter)
%
% Example
% 
% model = 
% 
%          TrainingSet: [40x94 double]
%                numPC: 2
%             Loadings: [94x2 double]
%          EigenMatrix: [2x2 double]
%              SD_mean: 0.0500
%              OD_mean: 1.3801e-08
%               DoF_SD: 1
%               DoF_OD: 9
%                level: [1x1 struct]
%                Alpha: 1.0000e-03
%                Gamma: 0.0500
%     EstimationMethod: 'classic'
%     TrainingSet_mean: [1x94 double]
% 
% >> model.level
% 
% ans = 
% 
%       critical: [29.5883 3.2876]
%        outlier: [28.9247 3.2139]
%     borderType: 'chi-square'
% 
% result - structure containing the validation result based on the DD-SIMCA model
% (struct)
% The result structure contains two optional fields: training and test. 
% The dd_plot function depends on the presence of these fields in the result structure.
% 
% result.training
% SD:  vector (1,n) with normalized squared Mahalanobis distances for objects
% from Training Set
% OD:  vector (1,n) with normalized squared Euclidian distances for objects
% from Training Set
% extreme:  has the same length as the number of objects
% in the training set. '1' indicates that the corresponding object is an
% extreme object.
% outlier:  has the same length as the number of objects
% in the training set. '1' indicates that the corresponding object is an
% outlier object.
% level: struct
% 	border: the border type in SIMCA plot:
%                   'convention' - classical rectangular border
%                   'chi-square' - triangular border defined for joint chi-squared
%   critical:  offset values for extreme border
%   outlier:  offset values for outlier border
% 
% result.test
% SD:  vector (1,m) with normalized squared Mahalanobis distances for objects
% from Test Set
% OD:  vector (1,m) with normalized squared Euclidian distances for objects
% from Test Set
% extreme:  has the same length as the number of objects
% in the test set. '1' indicates that the corresponding object is outside the
% acceptance area.
% Beta: double - calculated type II error
% Warning: char - a warning text is shown in case the test class is
% splitted into several subclasses.
%
% In case the input argument TestSet is a cellaray of matrices, the
% result.test is a cellarray of the corresponding structures.
% 
% Example
%
% >> result
% 
% result = 
% 
%     training: [1x1 struct]
%         test: [1x1 struct]
% 
% >> result.training
% 
% ans = 
% 
%          SD: [40x1 double]
%          OD: [40x1 double]
%     extreme: [40x1 double]
%     outlier: [40x1 double]
%       level: [1x1 struct]
% 
% result.training.level
% 
% ans = 
% 
%     borderType: 1
%       critical: [29.5883 3.2876]
%        outlier: [28.9247 3.2139]
% 
% >> result.test
% 
% ans = 
% 
%          SD: [50x1 double]
%          OD: [50x1 double]
%     extreme: [50x1 double]
%        Beta: 4.0114e-04
%     Warning: 'The test set is splitted into several subclasses!'
% 
% References
% [1] A.L. Pomerantsev, O.Ye. Rodionova, "Concept and role of extreme objects in PCA/SIMCA",  J. Chemometrics, 28, 429-438 (2014) DOI: 10.1002/cem.2506
% [2] A.L. Pomerantsev, O.Ye. Rodionova, "On the type II error in SIMCA method",  J. Chemometrics, 28, 518-522 (2014) DOI: 10.1002/cem.2610
%
% See also DDS_PLOT

if nargin >= 2 && nargout == 1 && isstruct(varargin{1})
    model = varargin{1};
    calc_beta = true;
    if ismatrix_(varargin{2})
        XTest = preprocess(model, varargin{2});
        
        if nargin == 3
            beta = varargin{3};
            result.test = dds_test(model, XTest, calc_beta, beta);
        else
            result.test = dds_test(model, XTest, calc_beta);
        end
        
    elseif isa(varargin{2}, 'cell')
        res = cell(1, length(varargin{2}));
        test_sets = varargin{2};
        for idx = 1:length(test_sets)
            XTest = preprocess(model, test_sets{idx});
            
            if nargin == 3
                beta = varargin{3};
                res{idx} = dds_test(model, XTest, calc_beta, beta);
            else
                res{idx} = dds_test(model, XTest, calc_beta);
            end
        end
        result.test = res;
    end
    
    varargout{1} = result;
else
if nargin < 2
    error('not enough parameters!');
else
    
    if nargin > 2 && mod(nargin - 2, 2) ~= 0
        error('parameters list has wrong format! use key-value format for parameters');
    end
    
    %training set
    if ~ismatrix_(varargin{1})
        error('training set is not a matrix!');
    end
    task.X = varargin{1};

    %number of PC
    if ~isa(varargin{2},'double')
    	error('number of PC has wrong format!');
    end
    task.numPC = varargin{2};

    params_struct = [];
    %fill parameters struct
    for i = 1:2:nargin-2
       if ~isa(varargin{2 + i},'char')
           error('!');
       end
       field = lower(strtrim(varargin{2 + i}));
       value = varargin{2 + i + 1};
       params_struct.(field) = value;
    end
    
    %estimation method
    if isfield(params_struct, 'method')
        if ~isa(params_struct.method,'char')
           error('unsupported estimation method! allowed methods: classic, robust');
        end
        task.method = lower(strtrim(params_struct.method));
    else
        task.method = 'classic';
    end
    
    %outlier offset
    if isfield(params_struct, 'gamma')
        if ~isa(params_struct.gamma,'double')
           error('outlier threshold has wrong format!');
        end
        task.Gamma = params_struct.gamma;
    end
    
    %alpha (type I error)
    if isfield(params_struct, 'alpha')
        if ~isa(params_struct.alpha,'double')
           error('alpha error has wrong format!');
        end
        task.Alpha = params_struct.alpha;
    end
    
    %beta (type II error)
    if isfield(params_struct, 'beta')
        if ~isa(params_struct.beta,'double')
           error('beta error has wrong format!');
        end
        task.Beta = params_struct.beta;
    end
    
    %calculate beta?
    if isfield(params_struct, 'calculatebeta')
        if ~isa(params_struct.calculatebeta,'logical')
           error('allowed modes: "true" - calculate beta for test set, "false" - do not calculate beta for test set. default: "true"');
        end
        task.CalculateBeta = params_struct.calculatebeta;
    else
        task.CalculateBeta = true;
    end
    
    %border type
    if isfield(params_struct, 'bordertype')
        if ~isa(params_struct.bordertype,'char')
           error('unsupported border type! allowed types: convention, chi-square. default: chi-square');
        end
        task.borderType = lower(strtrim(params_struct.bordertype));
    else
        task.borderType = 'chi-square';
    end
    
    %preprocess (mean-centering)
    if isfield(params_struct, 'centering')
        if ~isa(params_struct.centering,'logical')
           error('allowed preprocessing modes: "true" - mean-centering, "false" - no mean-centering. default: "false"');
        end
        task.centering = params_struct.centering;
    else
        task.centering = false;
    end
    
    %preprocess (normalizing)
    if isfield(params_struct, 'normalizing')
        if ~isa(params_struct.normalizing,'logical')
           error('allowed preprocessing modes: "true" - normalizing, "false" - no normalizing. default: "false"');
        end
        task.normalizing = params_struct.normalizing;
    else
        task.normalizing = false;
    end
    
    if task.centering == true
       X_mean = mean(task.X);
       task.X = bsxfun(@minus, task.X, X_mean);
    end
    
    if task.normalizing == true
       X_std = std(task.X,1,1);
       task.X = bsxfun(@rdivide, task.X, X_std);
    end

    %test set (possibly, multiple)
    if isfield(params_struct, 'testset')
        if ~ismatrix_(params_struct.testset) && ~isa(params_struct.testset, 'cell')
           error('test set is not a matrix or cell array!');
        end
        task.XTest = params_struct.testset; 
        if task.centering == true
            if isa(params_struct.testset, 'cell')
                task.XTest = cellfun(@(x) bsxfun(@minus, x, X_mean), task.XTest, 'UniformOutput', false);
            else
                task.XTest = bsxfun(@minus, task.XTest, X_mean);
            end
        end
    
        if task.normalizing == true
            if isa(params_struct.testset, 'cell')
                task.XTest = cellfun(@(x) bsxfun(@rdivide, x, X_std), task.XTest, 'UniformOutput', false);
            else
                task.XTest = bsxfun(@rdivide, task.XTest, X_std);
            end
        end
        
    end
end

%main logic
[model, result] = dds_process(task);

        if task.centering == true
            model.TrainingSet_mean = X_mean;
        end
    
        if task.normalizing == true
            model.TrainingSet_std = X_std;
        end

% calculation of SD, OD and Beta (optional) for XTest
if isfield(task, 'XTest')

    if ismatrix_(task.XTest)
        if isfield(task, 'Beta')
            result.test = dds_test(model, task.XTest, task.CalculateBeta, task.Beta);
        else
            result.test = dds_test(model, task.XTest, task.CalculateBeta);
        end
        
    elseif isa(task.XTest, 'cell')
        res = cell(1, length(task.XTest));
        test_sets = task.XTest;
        for idx = 1:length(test_sets)
            
            if isfield(task, 'Beta')
                res{idx} = dds_test(model, test_sets{idx}, task.CalculateBeta, task.Beta);
            else
                res{idx} = dds_test(model, test_sets{idx}, task.CalculateBeta);
            end
        end
        result.test = res;
    end
end

if nargout == 1
    varargout{1} = model;
end
    
if nargout == 2
    varargout{1} = model;
    varargout{2} = result;
end
end
% end of dd_simca function

function [model, result] = dds_process(task)
Gamma = [];
X = task.X;
numPC = task.numPC;
if isfield(task, 'Gamma')
    Gamma = task.Gamma;
end

n = size(X, 1);
[P,D1]= decomp (X, numPC);

switch task.borderType    
    case 'convention'
        border_type = 0; 
    case 'chi-square'    
        border_type = 1;
end    

% calculation of OD and SD for a training set
v_sdT=sd(X,P(:,1:numPC),D1,numPC);
v_odT=od(X,P(:,1:numPC));
switch task.method    
    % Classical estimators
    case 'classic'
        [av_sd,DoF_sd]=momentest(v_sdT);
        [av_od,DoF_od]=momentest(v_odT);
     % Robust estimators   
    case 'robust'    
        [av_sd,DoF_sd]=robustest(v_sdT);
        [av_od,DoF_od]=robustest(v_odT);
end
v_sdT_=v_sdT/av_sd;
v_odT_=v_odT/av_od;

%extreme borders for OD and SD; array of extreme objects

if ~(isfield(task, 'Alpha'))
    alphaError = alpha_error(DoF_sd*v_sdT_+DoF_od*v_odT_, DoF_sd+DoF_od);
else
    alphaError = task.Alpha;
end

dcrit=border(DoF_od, DoF_sd, border_type, alphaError);
v_extT=extremes(v_odT_,v_sdT_,dcrit, border_type);

dout = [];
v_outT = [];
if ~isempty(Gamma)
%outlier borders for OD and SD; array of outlier objects
    alpha_out=1-((1-Gamma)^(1/n));
    dout=border(DoF_od, DoF_sd, border_type, alpha_out);
    v_outT=extremes(v_odT,v_sdT, dout, border_type);
end

model = dds_model(X, numPC, P(:,1:numPC), D1, av_sd, av_od, DoF_sd, DoF_od, task.borderType, dcrit, dout, alphaError, Gamma, task.method);
result.training = dds_result('plot', v_sdT, v_odT, v_extT, v_outT);
result.training.level = dds_result('level', border_type, dcrit, dout);

function dbord=border(DoF_od, DoF_sd, border_type, error)
% calculate critical values dbord(1) for score distance and dbord(2) for
% orthogonal distance
%border_type=0 : application of rectangle border
%border_type=1: application of triangle border
%----------------------------------------------
if (border_type==0)
    sd_Crit=chi2inv_(sqrt(1-error),DoF_sd)/DoF_sd;
    od_Crit=chi2inv_(sqrt(1-error),DoF_od)/DoF_od;
end
if (border_type==1)
    d_Crit=chi2inv_(1-error,DoF_sd+DoF_od);
    sd_Crit=d_Crit/DoF_sd;
    od_Crit=d_Crit/DoF_od;
end
dbord(1)=sd_Crit;
dbord(2)=od_Crit;
% end of dbord function

function samp_out = extremes(v_od,v_sd, dbord, border_type)
%form vector with "1" if a sample located out of the acceptance area and "0" for
%regular samples
%----------------------------------------------
n = size(v_od, 1);
v_samp=zeros(n,1);
sd_Crit=dbord(1);
od_Crit=dbord(2);
if (border_type==0)  
    for k=1:n
        if (v_sd(k,1)<sd_Crit)||(v_sd(k,1)<0)
            if(v_od(k,1)>od_Crit)
                v_samp(k,1)=1;
            end
        else
           v_samp(k,1)=1; 
        end   
    end
end
if (border_type==1) 
    for k=1:n
        if (v_sd(k,1)>sd_Crit)||(v_sd(k,1)<0)
                v_samp(k,1)=1;
            else
             od_Cur=od_Crit/sd_Crit*(sd_Crit-v_sd(k,1));
             if(v_od(k,1)>od_Cur)
                v_samp(k,1)=1; 
            end
        end   
    end
end
samp_out=v_samp;
% end of samp_out function

function [P,D1]= decomp (X, numPC)
% decomp - PCA decomposition based on X matrix with numPC components 
%----------------------------------------------
[~,D,P] = svd(X);
D1=D(1:numPC,1:numPC);
% end of decomp function

function [aver, DoF]= momentest(v_uT)
% momentest -estimation of DoF by method of moments, and estimation of% mean value
%----------------------------------------------
aver=mean(v_uT);
DoF=round(2*(aver/std(v_uT))^2);
if (DoF < 1)
    DoF=1;
end;
% end of momentest function

function [aver, DoF]= robustest(v_uT)
% robustest - estimation of mean and DoF in a robust manner
%----------------------------------------------
M=median(v_uT);
R=iqr(v_uT);
DF=R/M;
if (DF > 2.685592117)
    DoF=1;
   elseif (DF < 0.194565995)
    DoF=100;
  else
    DoF = round(exp((1.380948*log(2.68631 / DF)) ^ 1.185789));
    R1=double(DoF);
 end      
aver=0.5*R1*((M/chi2inv_(0.5,R1))+(R/(chi2inv_(0.75,R1)-chi2inv_(0.25,R1))));
% end of robustest function

function v_sd =sd(X,P,D,numPC)
% sd - Scores distance function, returns v_sd- vector of score distances for specified PCs
%----------------------------------------------
n = size(X, 1);
T = X*P;
v_lambd = diag(D);
v_work=zeros(n,numPC);
v_sd=zeros(n,1);
for k=1:numPC
    v_work(:,k)=T(:,k)/v_lambd(k);
end
for k=1:n
    v_sd(k,1)=sum(v_work(k,:).*v_work(k,:));
end    
% end of sd function

function v_od=od(X,P)
% od - orthogonal distance function, returns v_od- ve
%vector of orthogonal distances for specified PCs
%----------------------------------------------
[n,p]=size(X);
E=X*(eye(p,p)-P*P');
v_od=zeros(n,1);
for k=1:n
    v_od(k,1)=sum(E(k,:).*E(k,:))/p;
end   
% end of od function

function model = dds_model(X, numPC, Loadings, EigenMatrix, SD_mean, OD_mean, DoF_SD, DoF_OD, borderType, levelCritical, levelOutlier, alphaError, Gamma, EstimationMethod)

model.TrainingSet = X;
model.numPC = numPC;
model.Loadings = Loadings;
model.EigenMatrix = EigenMatrix;
model.SD_mean = SD_mean;
model.OD_mean = OD_mean;
model.DoF_SD = DoF_SD;
model.DoF_OD = DoF_OD;
model.EstimationMethod = EstimationMethod;

model.level.critical = levelCritical;

if ~isempty(levelOutlier)
    model.level.outlier = levelOutlier;
end

model.level.borderType = borderType;  

model.Alpha = alphaError;
model.Gamma = Gamma;

function result = dds_result(mode, varargin)

mode1 = lower(strtrim(mode));
if nargin > 1
    
    switch mode1    
        case 'plot'
            result.SD = varargin{1};
            result.OD = varargin{2};
            result.extreme = varargin{3};
            if nargin == 5
                result.outlier = varargin{4};
            end
        case 'level'
            result.borderType = varargin{1};
            result.critical = varargin{2};            
            if nargin == 4
                result.outlier = varargin{3};
            end       
    end
    
end

function result = dds_test(model, XTest, calc_beta, beta)

Xnew = XTest;
numPC = model.numPC;
P = model.Loadings;
D1 = model.EigenMatrix;
av_sd = model.SD_mean;
av_od = model.OD_mean;
dcrit = model.level.critical;
%dout = model.level.outlier;

switch model.level.borderType    
    case 'convention'
        border_type = 0; 
    case 'chi-square'    
        border_type = 1;
end   

v_sdNew=sd(Xnew,P,D1,numPC);
v_odNew=od(Xnew,P);
v_extNew=extremes(v_odNew/av_od,v_sdNew/av_sd, dcrit, border_type);
%v_outNew=extremes(v_odNew,v_sdNew, dout, border_type);

result = dds_result('plot', v_sdNew, v_odNew, v_extNew);

if calc_beta
    if nargin > 3
        beta_res = beta_error(model, XTest, beta);
    else
        beta_res = beta_error(model, XTest);
    end
    
    if isfield(beta_res, 'alpha')
        result.levelCritical = beta_res.levelCritical;
        result.TestSet_Alpha = beta_res.alpha;
    end

    if isfield(beta_res, 'beta')
        result.Beta = beta_res.beta;
    end

    if isfield(beta_res, 'warning')
        result.Warning = beta_res.warning;
    end
end

function result = beta_error(model, X1, beta)
% beta_error -  function, returns type II error for Test set
%----------------------------------------------

%beta is optional
if nargin == 2
    beta = 0;
end

%Init
numPC = model.numPC;
P = model.Loadings;
L = model.EigenMatrix;
h0 = model.SD_mean;
v0 = model.OD_mean;
Nh = model.DoF_SD;
Nv = model.DoF_OD;

if isfield(model, 'Alpha') && beta == 0
    alpha = model.Alpha;
else
    alpha = 0;
    if beta == 0
        error('Both alpha and beta errors are not specified!');
    end
end

%Step 0
%Calculate  T' and  E' 
%T1 = X1*P;
%E1 = X1 - T1*P';

%Calculate  hi' and vi'
sd1 = sd(X1,P,L,numPC)/h0;
od1 = od(X1,P)/v0;

%Calculate  ci'
c1 = Nh*sd1 + Nv*od1;

%Order c' such that c1'<= c2'<=.... <= cI''
c1 = sort(c1);

flag = true;
I1 = size(X1, 1);
k = Nh + Nv;
while flag
    %Step 1
    %Calculate  m' and d'  
    m1 = sum(c1)/I1;
    d1 = sum((c1 - m1).^2)/(I1-1);

    %Calculate  M1 and Disc
    M1 = d1/m1^2;
    Disc = 4 - 2*k*M1;
    
    %Step 2
    if Disc < 0
       %warning('The test set is splitted into several subclasses!');
       result.warning = 'The test set is splitting into several subclasses!';
       c1 = c1(1:end-1,:);
       I1 = I1 - 1;
    else
       break;
    end
end

%Step 3
%Calculate  x  
x = (2 + sqrt(Disc))/M1;

%Calculate  s and  c'0
s = x - k;
c0 = m1/x;

%Calculate:  h, q, p, Mz, Sz 
h = 1 - 2*(k + s)*(k + 3*s)/3/(k + 2*s)^2;
q = (h - 1)*(1 - 3*h);
p = (k + 2*s)/(k + s)^2;
Mz = 1 + h*p*(h - 1 - 0.5*(2 - h)*q*p);
Sz = h*sqrt(2*p)*(1 + 0.5*q*p);

%Step 4
%If alpha is given then calculate beta
if alpha ~= 0
    Ccrit = chi2inv_(1-alpha, Nh + Nv);
    z = Ccrit/c0;
    beta = normcdf_(((z/(k + s))^h - Mz)/Sz);
    
    if beta < 1e-8
        beta = 0; 
    end
    
    result.beta = beta;
else
    %If beta is given then calculate Ccrit, and calculate alpha
    if beta ~= 0
        Zb = norminv_(1-beta);
        Ccrit = c0*(k + s)*(Sz*Zb + Mz)^(1/h);
        alpha = 1 - chi2cdf_(Ccrit, k);
        
        if alpha < 1e-8
           alpha = 0; 
        end
        
        result.alpha = alpha;
        %result.levelCritical = Ccrit;
    end
end
% end of beta_error function

function res = ismatrix_(a)
%Determine whether input is a matrix.
%for compatibility with earlier matlab versions

[n,p] = size(a);
if n > 1 && p > 1 && isa(a, 'double')
    res = true;
else
    res = false;
end
    
function alpha = alpha_error(c,k)

Ccrit = max(c) + 0.0001;
alpha = 1 - chi2cdf_(Ccrit, k);

function res = preprocess(model, XTest1)
XTest = XTest1;
if isfield(model, 'TrainingSet_mean')
  XTest = bsxfun(@minus, XTest, model.TrainingSet_mean);
end       
if isfield(model, 'TrainingSet_std')
  XTest = bsxfun(@rdivide, XTest, model.TrainingSet_std);
end
res = XTest;

function r = chi2cdf_(val, dof)
%Chi-square cumulative distribution function.

%if exist('chi2cdf', 'file')
%    r = chi2cdf(val, dof);
%else
    %If Statistics Toolbox is absent
    x1 = val;
    n = dof;
    
    if n<=0 || x1<0
        error('!!!');
    end
    
    if n > 140
        x=sqrt(2*x1)-sqrt(2*n-1);
        P=normcdf_(x);
        r = P;
        return;
    end
    
	x=sqrt(x1);
    if mod(n,2) == 0
		%if n is even
            a=1;
            P=0;
            for i=1:(n-2)/2
				a = a*x*x/(i*2);
				P = P + a;
            end
			P = P + 1;
			P = P*exp(-x*x/2);
	else
		%if n is odd
            a=x;
            P=x;
            for i=2:(n-1)/2
    			a = a*x*x/(i*2-1);
				P = P + a;
            end
            if n==1
				P=0;
			else
				P = P*exp(-x*x/2)*2/sqrt(2*pi);
            end
            P = P + 2*(1-normcdf_(x));
    end
	r = 1-P;
%end

function r = chi2inv_(p, dof)
%Inverse of the chi-square cumulative distribution function (cdf).

%if exist('chi2inv', 'file')
%    r = chi2inv(p, dof);
%else
    %If Statistics Toolbox is absent
    n = dof;
    
    if n<=0||p<0||p>1
        error('!!!');
    end
    
    if p==0
       r = 0;
       return;
    end
    
    if p==1
       r = inf;
       return;
    end
    
    z = norminv_(p);
    dTemp1=2/9/n;
	dTemp=1-dTemp1+z*sqrt(dTemp1);
    
    if dTemp1>0
        dTemp1=dTemp*dTemp*dTemp;
        f=n*dTemp1;
    else
        dTemp1=z+sqrt(2*n-1);
        dTemp=dTemp1*dTemp1;
		f=0.5*dTemp;
    end
    
    p1 = chi2cdf_(f, n);
    if p1 == p
        r = f;
        return;   
    end
    h = 0.01;
    if p1>p
		h=-0.01;
    end
    
    flag = true;
    while flag
        
        z=f+h;
        if z<=0
			break;
        end
		h = h*2;
		p1=chi2cdf(z,n);
        
        flag = (p1-p)*h<0;
    end
    
    if p1==p
        r = z;
        return;
    end
    
    if z<=0
        z=0;
    end
    
    if f<z
        x1=f;
		x2=z;
    else
        x1=z;
		x2=f;
    end
    
    for i=0:50000
        f=(x1+x2)/2.0;
		p1=chi2cdf_(f,n);
        
        if abs(p1-p)<0.001*p*(1-p)&& abs(x1-x2)<0.0001*abs(x1)/(abs(x1)+abs(x2))
			break;
        end
        
        if p1<p
			x1=f;
		else
			x2=f;
        end
    end
    
    r = f;
%end

function r = normcdf_(x)
%Normal cumulative distribution function (cdf).

%if exist('normcdf', 'file')
%    r = normcdf(x);
%else
    %If Statistics Toolbox is absent
    t = 1 /(1 + abs(x)*0.2316419);
	P = 1 - (exp(-x*x/2)/sqrt(2*pi))*t*((((1.330274429*t-1.821255978)*t+1.781477937)*t-0.356563782)*t+0.31938153);
    if x <= 0 
		P = 1 - P;
    end
    r = P;
%end

function r = norminv_(P)
%Inverse of the normal cumulative distribution function (cdf).

%if exist('norminv', 'file')
%    r = norminv(val);
%else
    %If Statistics Toolbox is absent
    if P>=1 || P<=0
        error('!!!');
    end

	q=P;
    if P>=0.5 
		 q=1-P;
    end
	t=sqrt(log(1/(q*q)));
	t2=t*t;
	t3=t2*t;
	xp=t-(2.515517+t*0.802853+t2*0.010328)/(1+t*1.432788+t2*0.189269+t3*0.001308);
    if P>=0.5 
		r = xp;
    else
        r = -xp;
    end
	
%end