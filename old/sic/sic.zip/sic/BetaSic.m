function bs=BetaSic(Res,p)
%Maximum error deviation calculation

[nRows,nCols]=size(Res);
nN=nCols*nRows;

dVar=sum(sum(Res.^2));
dBetaR=max(Res);
BetaRes=dBetaR;

dVar=sqrt(dVar/nN)/dBetaR;

dA1 = (1 - 172.812 / (nN ^ 1.5287)) / (1 + 172.812 / (nN ^ 1.1626));
    dA2 = 0.9572 * (1 - exp(-17.8528 / sqrt(nN)));
    dD = 0.2011 * (1 - exp(-73.4113 / nN));
    dXp =quantilnorm(p);
    dTemp = dA1 * dVar + dA2 - dXp * dD;
    BetaSic = dBetaR / dTemp;
bs=BetaSic;