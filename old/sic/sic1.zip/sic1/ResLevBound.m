function [Residuals,Leverage,Boundary]=ResLevBound(y,vmax,vmin,beta)
%Residuals, Levarage & Boundary values calculation
Residuals=(y-(vmax+vmin)/2)/beta
Leverage=((vmax-vmin)/2)/beta
Boundary=abs(Residuals)-(1-Leverage)
