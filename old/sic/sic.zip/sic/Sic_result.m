function output=Sic_result(Tc,Tt,Yc,Yt,Yc_pred,Yt_pred,Beta,nPC,MeanY,SdevY)
%SIC method implementation
%
%
format long;
disp('  ');
%
[Yc_r,Yc_c]=size(Yc);
[Tc_r,Tc_c]=size(Tc);
[Yt_r,Yt_c]=size(Yt);
[Tt_r,Tt_c]=size(Tt);
[Ycp_r,Ycp_c]=size(Yc_pred);
[Ytp_r,Ytp_c]=size(Yt_pred);

ec=0;

try
if(Yt_r==0 || Yt_c==0)   
    Yt_r=Tt_r;
    Yt_c=1;
    rmsep=0;
else
    rmsep=RMSE(Yt,Yt_pred);
end;
if(isnumeric(Beta)==1)
    opt=optimset('Display','off');
    [F,Shift,yy]=toEllipse(Yc,Tc,Beta);
    if(isreal(Shift)==1)
        [a,fval,exitflag] = linprog(ones(1,nPC),F,yy,[],[],[],[],[],opt);
    else
        exitflag=0;
    end;
    if(exitflag<=0)
        disp('  ');
       disp('Wrong Beta! Try a greater value.');
        ec=1;
    end;
end;  

if( (ischar(Beta)==1 && strcmp(upper(Beta),'BETAMIN')==0 && strcmp(upper(Beta),'BETASIC')==0 )|| (isnumeric(Beta)==1 && (Beta<0)))
    disp('  ');
    disp('Possible values for Beta are:');
    disp('BetaMin , BetaSic , <unsigned number>');
    ec=1;
end;
if nPC <= 0 || nPC>Tc_c
    disp('  ');
    disp('Number of PC should be more than 0 and less than Tc minimal dimension!');
    ec=1;
end;
if Tc_r ~= Yc_r
    disp('  ');
    disp('Number of rows in Tc and Yc should be equal!');
    ec=1;
end;
if Tt_r ~= Yt_r
    disp('  ');
    disp('Number of rows in Tt and Yt should be equal!');
    ec=1;
end;
if Yc_c ~= 1 || Yt_c ~= 1
    disp('  ');
    disp('Too many columns in Yc or Yt!');
    ec=1;
end;
if Ycp_c ~= 1 || Ytp_c ~= 1
    disp('  ');
    disp('Too many columns in Yc_pred or Yt_pred!!');
    ec=1;
end;
if Ycp_c ~= Yc_c && Ycp_r ~= Yc_r
    disp('  ');
    disp('Dimensions of Yc & Yc_pred should be equal!');
    ec=1;
end;
if Ytp_c ~= Yt_c && Ytp_r ~= Yt_r
    disp('  ');
    disp('Dimensions of Yt & Yt_pred should be equal!');
    ec=1;
end;
if Ytp_c ~= Yt_c && Ytp_r ~= Yt_r
    disp('  ');
    disp('Dimensions of Yt & Yt_pred should be equal!');
    ec=1;
end;

if ec==1
    nonexistent_function_to_invoke_an_error;
end;

Tc=Tc(:,1:nPC);
Tt=Tt(:,1:nPC);

%dotted estimation
Ypred_cal=Yc_pred;
Ypred=Yt_pred;

%beta
prob=0.95;

if(strcmp(upper(Beta),'BETAMIN')==1)
    bsic=BetaSic(abs(Ypred_cal-Yc),prob);
    beta=BetaMin(Tc,Yc,bsic,nPC);
end;
if(strcmp(upper(Beta),'BETASIC')==1)beta=BetaSic(abs(Ypred_cal-Yc),prob);;end;
if(isnumeric(Beta)==1 && Beta >=0)beta=Beta/SdevY;end;

opt=optimset('Display','off','LargeScale','off');
%sic intervals
[F,Shift,yy]=toEllipse(Yc,Tc,beta);
[mt,nt]=size(Tt);
for i=1:mt
    a=linprog(Tt(i,:),F,yy,[],[],[],[],[],opt);
    a=a-Shift;
    vmin1(i)=Tt(i,:)*a;
    a=linprog(-Tt(i,:),F,yy,[],[],[],[],[],opt);
    a=a-Shift;
    vmax1(i)=Tt(i,:)*a;
end

beta=beta*SdevY;

%output
Yt=Postprocess(Yt,MeanY,SdevY);

vmax1=Postprocess(vmax1,MeanY,SdevY);
Vmax=vmax1'
Ypred=Postprocess(Ypred,MeanY,SdevY)
vmin1=Postprocess(vmin1,MeanY,SdevY);
Vmin=vmin1'
RMSEC=RMSE(Yc,Yc_pred)
RMSEP=rmsep

output=struct('MeanY',{MeanY},'SdevY',{SdevY},'nPC',{nPC},'Y_test',{Yt},'Y_pred',{Ypred},'Vmax',{Vmax},'Vmin',{Vmin},'Beta',{beta},'RMSEC',{RMSEC},'RMSEP',{rmsep});

paint(Vmin,Vmax,Ypred,Yt,beta,nPC);
catch
    %disp(lasterr)
output=struct('MeanY',{0},'SdevY',{0},'nPC',{0},'Y_test',{0},'Y_pred',{0},'Vmax',{0},'Vmin',{0},'Beta',{0},'RMSEC',{0},'RMSEP',{0});

end

