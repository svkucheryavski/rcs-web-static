function paint(xmin,xmax,xpred,xtest,err,nPc)
%SIC-interval plotting
%
%
figure;

if ishandle(gca)
  delete(gca);  
end
[xt_r,xt_c]=size(xtest);

col_g=[0 1 0];
col_b=[0.6 0.6 1];


if(xt_r~=0 ||xt_c~=0)
    
hold on;

[m,n]=size(xmin);
ulim=max(m,n);
x1=max(xmax);
x2=max(xpred);
x3=max(xtest+err);
m1=max(x1,x2);
m2=max(m1,x3);

plim=m2+0.5;
%
x1=min(xmin);
x2=min(xpred);
x3=min(xtest-err);
m1=min(x1,x2);
m2=min(m1,x3);

llim=m2-0.5;
%
SampNum=ulim+0.5;
LowLim=llim;
UppLim=plim;

axis ([0 SampNum LowLim UppLim]);
plot([1 1],[xmax(1)-0.02 xmax(1)],'LineWidth',10,'Color',col_b);
h0=plot([1 1],[xmin(1) xmax(1)],'LineWidth',10,'Color',col_b);

plot([1 1],[0 xtest(1)+err],'LineWidth',1,'Color',col_b);
plot([1 1],[xtest(1)-err xtest(1)+err],'-ks','LineWidth',2,'MarkerSize',2);

 
for i=2:ulim
 plot([i i],[xmax(i)-0.02 xmax(i)],'-','LineWidth',10,'Color',col_b);
 plot([i i],[xmin(i) xmax(i)],'-','LineWidth',10,'Color',col_b);

 plot([i i],[0 xtest(i)+err],'LineWidth',1,'Color',col_b);
 plot([i i],[xtest(i)-err xtest(i)+err],'-ks','LineWidth',2,'MarkerSize',2);
   
end

h1=plot(xpred,'or','MarkerFaceColor','r','MarkerSize',5);
h2=plot(xtest,'ok','MarkerFaceColor','w','MarkerSize',5);
h=[h0 h1 h2];
legend(h,'SIC', 'Predicted','Test');

else
    
 hold on;

[m,n]=size(xmin);
ulim=max(m,n);
x1=max(xmax);
x2=max(xpred);
m1=max(x1,x2);

plim=m1+0.5;

x1=min(xmin);
x2=min(xpred);
x3=min(xtest-err);
m1=min(x1,x2);

llim=m1-0.5;

SampNum=ulim+0.5;
LowLim=llim;
UppLim=plim;

axis ([0 SampNum LowLim UppLim]);
plot([1 1],[xmax(1)-0.02 xmax(1)],'LineWidth',10,'Color',col_b);
h0=plot([1 1],[xmin(1) xmax(1)],'LineWidth',10,'Color',col_b);
plot([1 1],[0 xpred(1)],'LineWidth',1,'Color',col_b);

for i=2:ulim
 plot([i i],[xmax(i)-0.02 xmax(i)],'-','LineWidth',10,'Color',col_b);
 plot([i i],[xmin(i) xmax(i)],'-','LineWidth',10,'Color',col_b);
 plot([i i],[0 xpred(i)],'LineWidth',1,'Color',col_b);
 
end

h1=plot(xpred,'or','MarkerFaceColor','r','MarkerSize',5);
h=[h0 h1];
legend(h,'SIC', 'Predicted');


end


plot([0 SampNum],[0 0],'k');

xlabel('Samples','FontSize',16);
ylabel('Values','FontSize',16);


title(strcat('Num. of PC = ',int2str(nPc),' ; Beta = ',num2str(err)),'FontSize',14);

hold off;

%set(gca,'fontsize',18);
