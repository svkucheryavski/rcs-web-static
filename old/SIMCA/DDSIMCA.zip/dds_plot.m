function varargout = dds_plot(mode, dds_model, dds_result, varargin)
% DDS_PLOT
% Acceptance and extreme plot for Data Driven SIMCA (DD-SIMCA)
% 
% Syntax
% extreme plot mode (for Training Set only)
% [N,Nplus,Nminus] = dds_plot(mode, model, result)
% N = dds_plot(mode, model, result)
%
% acceptance plot mode (for Training and Test Sets, depending on the result structure)
% dds_plot(mode, model, result, Name,Value)
% 
% Example
% dds_plot('acceptance', model, result, 'Transform', 'sqrt', 'PointTitlesTest', Names);
% dds_plot('acceptance', model, result);
% [N,Nplus,Nminus] = dds_plot('extreme', model, result);
%
% Name-Value Pair Arguments
% Specify optional comma-separated pairs of Name,Value arguments. Name is the argument name and Value is the corresponding value. Name must appear inside single quotes (' '). You can specify several name and value pair arguments in any order as Name1,Value1,...,NameN,ValueN.
% Example: 'Transform','log'
%
%Transform - visual transformation of result data SD and OD (string),
%values: none | sqrt | log (default)
%
%PointTitlesTest - cellarray of names of objects in the test or new set (optional)
%
% See also DD_SIMCA

mode1 = lower(strtrim(mode));
PointTitlesTest = [];
%PointTitlesTraining = [];

if nargin > 3
    
    if mod(nargin - 3, 2) ~= 0
        error('parameters have wrong format! use key-value format for parameters');
    end
    
    %fill parameters struct
    for i = 1:2:nargin-3
       if ~isa(varargin{i},'char')
           error('!');
       end
       field = lower(strtrim(varargin{i}));
       value = varargin{i+1};
       params_struct.(field) = value;
    end
    
    %transform
    if isfield(params_struct, 'transform')
        if ~isa(params_struct.transform,'char')
           error('unsupported transformation method! allowed methods: none, sqrt, log. default: log');
        end
        transform = lower(strtrim(params_struct.transform));
    else
        transform = 'log';
    end
   
    %point titles
    if isfield(params_struct, 'pointtitlestest')
        if ~isa(params_struct.pointtitlestest, 'double') && ~isa(params_struct.pointtitlestest, 'cell')
           error('titles parameter is not a vector or cell array!');
        end
        if isa(params_struct.pointtitlestest, 'cell')
            PointTitlesTest = params_struct.pointtitlestest;
        else
            PointTitlesTest = cellfun(@(x) sprintf('%d',x), num2cell(params_struct.pointtitlestest), 'UniformOutput', false);
        end
    end
    
else
    transform = 'log';
end

switch mode1    
    case 'acceptance'
        
        if isfield(dds_result, 'training')

        figure;
        hold on;
        title('Acceptance plot. Training set', 'FontWeight', 'bold');
        
        xlabel('h/h_0', 'FontWeight', 'bold');
        ylabel('v/v_0', 'FontWeight', 'bold');
        
        switch transform
            case 'sqrt'
                xlabel('(h/h_0)^1^/^2', 'FontWeight', 'bold');
                ylabel('(v/v_0)^1^/^2', 'FontWeight', 'bold');
            case 'log'
                xlabel('log(1 + h/h_0)', 'FontWeight', 'bold');
                ylabel('log(1 + v/v_0)', 'FontWeight', 'bold');
        end

        if isfield(dds_model, 'level')
            crit_levels = dds_model.level.critical;

            [x,y] = plot_border(crit_levels, dds_model.level.borderType, transform);
            
            plot(x, y, '-g');
            if isfield(dds_model.level, 'outlier')
                out_levels = dds_model.level.outlier;
                [x,y] = plot_border(out_levels, dds_model.level.borderType, transform);
            
                plot(x, y, '-r');
            end
        end
            OD = transform_(transform, dds_result.training.OD/dds_model.OD_mean);
            SD = transform_(transform, dds_result.training.SD/dds_model.SD_mean);
            
            if isfield(dds_model.level, 'outlier')
                extTraining = dds_result.training.extreme;
                outTraining = dds_result.training.outlier;
                regular = plot(SD(extTraining == 0 | outTraining == 0),OD(extTraining == 0 | outTraining == 0),'og','MarkerFaceColor','g');
                extreme = plot(SD(extTraining == 1),OD(extTraining == 1),'s','Color',[1 0.65 0],'MarkerFaceColor',[1 0.65 0]);
                outlier = plot(SD(outTraining == 1),OD(outTraining == 1),'rs','MarkerFaceColor','r');
                if sum(extTraining == 1) > 0 && sum(outTraining == 1) > 0
                    legend([regular, extreme, outlier],'regular','extremes','outliers');
                end
                if sum(extTraining == 1) > 0 && sum(outTraining == 1) == 0
                    legend([regular, extreme],'regular','extremes');
                end
                if sum(extTraining == 1) == 0 && sum(outTraining == 1) > 0
                    legend([regular, outlier],'regular','outliers');
                end
                if sum(extTraining == 1) == 0 && sum(outTraining == 1) == 0
                    legend(regular,'regular');
                end
            else
                extTraining = dds_result.training.extreme;
                regular = plot(SD(extTraining == 0),OD(extTraining == 0),'og','MarkerFaceColor','g');
                extreme = plot(SD(extTraining == 1),OD(extTraining == 1),'s','Color',[1 0.65 0],'MarkerFaceColor',[1 0.65 0]);
                if sum(extTraining == 1) > 0
                    legend([regular, extreme],'regular','extremes');
                end
                if sum(extTraining == 1) == 0
                    legend(regular,'regular');
                end 
            end
            
            legend('boxon');
            hold off;
        end

        if isfield(dds_result, 'test')
            
            figure;
            hold on;
            title('Acceptance plot. Test set', 'FontWeight', 'bold');
            
            xlabel('h/h_0', 'FontWeight', 'bold');
            ylabel('v/v_0', 'FontWeight', 'bold');
        
            switch transform
                case 'sqrt'
                    xlabel('(h/h_0)^1^/^2', 'FontWeight', 'bold');
                    ylabel('(v/v_0)^1^/^2', 'FontWeight', 'bold');
                case 'log'
                    xlabel('log(1 + h/h_0)', 'FontWeight', 'bold');
                    ylabel('log(1 + v/v_0)', 'FontWeight', 'bold');
            end
            
        if isfield(dds_result.test, 'level')
            crit_levels = dds_result.test.critical;
            [x,y] = plot_border(crit_levels, dds_model.level.borderType, transform);
            plot(x, y, '--g');
        else
            if isfield(dds_model, 'level')
                crit_levels = dds_model.level.critical;

                [x,y] = plot_border(crit_levels, dds_model.level.borderType, transform);
            
                plot(x, y, '-g');

            end
        end
        
           if isa(dds_result.test, 'cell')
               
               marks = 'osd*+.x^v><ph';
               mark_idx = 1;
               color_idx = 0;
               n_marks = length(marks);
               colors = 'rgbmcyk';
               n_colors = length(colors);
               for idx = 1:length(dds_result.test)
                   
                   color_idx = color_idx + 1;
                   if color_idx > n_colors
                       color_idx = 1;
                       mark_idx = mark_idx + 1;
                       if mark_idx > n_marks;
                        error('Too many classes');
                       end
                   end
                   
                   mark = marks(mark_idx);
                   color = colors(color_idx);
                   
                   OD_New = transform_(transform, dds_result.test{idx}.OD/dds_model.OD_mean);
                   SD_New = transform_(transform, dds_result.test{idx}.SD/dds_model.SD_mean);
                    
                   plot(SD_New, OD_New, [mark color],'MarkerFaceColor', color);
               end
               
           else
               
                OD_New = transform_(transform, dds_result.test.OD/dds_model.OD_mean);
                SD_New = transform_(transform, dds_result.test.SD/dds_model.SD_mean);
                extNew = dds_result.test.extreme;
                %outNew = dds_result.test.outlier;
            
                %plot(SD_New, OD_New,'ob','MarkerFaceColor','b');
                plot(SD_New(extNew == 0),OD_New(extNew == 0),'og','MarkerFaceColor','g');
                plot(SD_New(extNew == 1),OD_New(extNew == 1),'or','MarkerFaceColor','r');

                if(~isempty(PointTitlesTest))
                    dx = 0.01; dy = 0.01; % displacement so the text does not overlay the data points
                    text(SD_New+dx, OD_New+dy, PointTitlesTest);
                end
               
           end
            
        
            
            

            hold off;
        end

    case 'extreme'
        if isfield(dds_result, 'training')
            OD = dds_result.training.OD/dds_model.OD_mean;
            SD = dds_result.training.SD/dds_model.SD_mean;
        else
            error('dds_result structure does not contain training set data!');
        end
        
        if ~isempty(dds_model)
            Nh = dds_model.DoF_SD;
            Nv = dds_model.DoF_OD;
        else
            error('no dds_model!');
        end
        
        c = Nh*SD + Nv*OD;
        c = sort(c);
        Nc = Nh + Nv;
        I = length(c);
        
        N = zeros(1,I);
        Nplus = zeros(1,I);
        Nminus = zeros(1,I);
        
        for n = 1:I
            alpha = n / I;
            Ccrit = chi2inv( 1 - alpha, Nc);
            N(n) = sum(c >= Ccrit);
            D = 2*sqrt(n*(1-alpha));
            Nplus(n) = n + D;
            Nminus(n) = n - D;
        end
        
        figure;
        hold on;
        title('Extreme plot', 'FontWeight', 'bold');
        xlabel('Expected', 'FontWeight', 'bold');
        ylabel('Observed', 'FontWeight', 'bold');

        expected = 1:length(N);
        exp_plot = plot(expected, expected, '-b', 'LineWidth', 2);
        
        for i = 1:length(expected)
            plot([expected(i),expected(i)],[Nminus(i),Nplus(i)], '-b');
        end
        
        n_plot = plot(expected, N, 'or','MarkerFaceColor','r');
        
        legend([n_plot,exp_plot],'Observed','Expected', 'Location', 'northwest');
        legend('boxon');
        
        if nargout == 1
            varargout(1) = N;
        end
        
        if nargout == 2
            error('not enough output parameters!');
        end
        
        if nargout == 3
            varargout{1} = N;
            varargout{2} = Nplus;
            varargout{3} = Nminus;
        end
        hold off;
    case 'pca'    
        %TBD
        %not enough input parameters
end
  
end

function [x, y] = plot_border(dcrit, border_type, transform)


sd_Crit=dcrit(1);
od_Crit=dcrit(2);

x = linspace(0,transform_(transform, sd_Crit));
n=length(x);
y=zeros(size(x));

switch border_type
    case 'convention'
    for k=1:n
        if( x(k) < transform_(transform, sd_Crit) || x(k) < 0)
            y(k)=od_Crit;
        else
            y(k)=0;
        end
    end
case 'chi-square' 
    for k=1:n
        if( x(k) > transform_(transform, sd_Crit) || x(k) < 0)
            y(k)=0;
        else
            %y(k)=od_Crit/sd_Crit*(sd_Crit-x(k));
            y(k)=od_Crit/sd_Crit*(sd_Crit-transform_reverse(transform, x(k)));
            
            if(y(k) < 0)
                y(k) = 0;
            end
        end
         
    end
end

 y = transform_(transform, y);
end

function res = transform_(mode, input)
res = input;
switch mode
    case 'sqrt'
       res = sqrt(input);
    case 'log'
       res = log(1 + input);
end
end

function res = transform_reverse(mode, input)
res = input;
switch mode
    case 'sqrt'
       res = input^2;
    case 'log'
       res = exp(input)-1;
end
end

