function quant=QuantilNorm(level)
%Fractile of normal distribution calculation
   
 if(level < 0.5)
       t=level;
   else
       t=1-level;
   end;
   
   t = sqrt(-2 * log(t));
   q = t - ((0.010328 * t + 0.802853) * t + 2.515517) / (((0.001308 * t + 0.189269) * t + 1.432788) * t + 1);
   
   if(level > 0.5)
       quant=q;
   else
       quant=-1*q;
   end;