function bm=BetaMin(x,y,b0,nPC)
%Minimal value of Beta
%
%
opt=optimset('Display','off');
%steps=0;
b=b0/2;
bmin=b0;
bold=0;
%bvec=[];
%bvec=[bvec bmin];
tic
while(1)
   % steps=steps+1;
    [F,Shift,yy]=toEllipse(y,x,b);
    if(isreal(Shift)==1)
        [a,fval,exitflag] = linprog(ones(1,nPC),F,yy,[],[],[],[],[],opt);
    else
        exitflag=0;
    end;
    if(exitflag>0)
        oK=1;
    else
        oK=0;
    end;
    
    
    if(oK==1)
        if (abs(bmin-bold)<0.01)
            if (b<bmin) bold=bmin;bmin=b;
     %           bvec=[bvec bmin];
            end;
            break;
        else
            if (b<bmin) bold=bmin;bmin=b;
%                bvec=[bvec bmin];
            end;
            b=b-b/4;
        end
    else
        b=b+b/4;
    end;
  %bold
   % b
  %bmin
end;
%toc
%steps=steps
%bvec'
%pause
bm=bmin;