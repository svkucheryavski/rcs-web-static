function res=RMSE(Y,Ypred)
%Root-Mean Square Error calculation
[m,n]=size(Y);
res=sqrt((sum((Ypred-Y).^2))/max(m,n));