function bnum=paintResLev(Res,Lev,Bound,Beta)
%SIC-Residuals & SIC-Leverage plotting
%
%

figure;
set(gca,'fontsize',16);
if ishandle(gca)
  delete(gca);  
end

hold on;

[n,m]=size(Lev);
[n1,m1]=size(Res);

axis ([0 max(1,max(Lev))+0.2 min(-1.5,min(Res)) max(1.5,max(Res))]);

plot([1 1],[min(-1.5,min(Res)),max(1.5,max(Res))],'k');

plot([1 0],[0 1],'k');
plot([1 0],[0 -1],'k');

plot([0 max(1,max(Lev))+0.2],[0 0],'k');

Res1=[];
Lev1=[];
Res0=[];
Lev0=[];
BSamp=[];

for i=1:n
 if (abs(Bound(i))<=0.0001) 
     Res1=[Res1 Res(i)];
     Lev1=[Lev1 Lev(i)];
     BSamp=[BSamp i];
 else
     Res0=[Res0 Res(i)];
     Lev0=[Lev0 Lev(i)];
 end; 
end;

h1=plot(Lev1,Res1,'og','MarkerFaceColor','g','MarkerSize',5);
h0=plot(Lev0,Res0,'or','MarkerFaceColor','r','MarkerSize',5);

for i=1:max(n,m)
text(Lev(i)*1.01,Res(i)*1.15,num2str(i),'FontSize',12);
end;

xlabel('SIC-Leverage','FontSize',12);
ylabel('SIC-Residual','FontSize',12);
title(strcat('Status Plot (Beta = ',num2str(Beta),')'),'FontSize',16);

hold off;
bnum=max(size(Res1));
disp('Boundary objects =')
disp(BSamp')